sudo apt-get update
sudo apt-get upgrade -y

# Install Deps
sudo apt install git -y
sudo apt install lsb-core -y
sudo apt install lsb-release -y

# Checkout the source and install
git clone https://github.com/STATION-I/stai-blockchain.git -b latest --recurse-submodules
ls -l
cd stai-blockchain || exit 1
ls -l

/bin/sh ./install.sh

. ./activate
stai init
ls -l
